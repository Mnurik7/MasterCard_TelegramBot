import os
import pandas as pd
import logging
from datetime import datetime, timedelta
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, InputFile
from telegram.ext import Application, CommandHandler, MessageHandler, CallbackQueryHandler, filters, ContextTypes
from telegram.error import Conflict, NetworkError
import re
import httpx
import json
import io
import matplotlib
matplotlib.use('Agg')  # Важно для работы без GUI
import matplotlib.pyplot as plt
import seaborn as sns
from dotenv import load_dotenv

# Загрузка переменных окружения из .env файла
load_dotenv()

# Настройка логирования
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Глобальная переменная для хранения данных
df = None

# История запросов пользователей (user_id -> list of queries)
user_history = {}

# Избранные запросы/результаты (user_id -> list of favorites)
user_favorites = {}

# Режим чата с ИИ для каждого пользователя (user_id -> bool)
ai_chat_mode = {}

# Кэш для статистики (чтобы не пересчитывать каждый раз)
stats_cache = None
cache_timestamp = None
CACHE_TTL = 300  # 5 минут

# Настройки OpenRouter API для ИИ агента
OPENROUTER_API_KEY = os.getenv('OPENROUTER_API_KEY', '') or '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'
OPENROUTER_API_URL = "https://openrouter.ai/api/v1/chat/completions"
# Используем бесплатную модель (можно изменить на другую)
OPENROUTER_MODEL = "meta-llama/llama-3.2-3b-instruct:free"

def load_transactions(csv_file='example_dataset.csv'):
    """Загрузка транзакций из CSV файла"""
    global df, stats_cache, cache_timestamp
    try:
        logger.info(f"Загрузка данных из {csv_file}...")
        df = pd.read_csv(csv_file, low_memory=False)
        
        # Преобразование timestamp в datetime (оптимизировано)
        df['transaction_timestamp'] = pd.to_datetime(df['transaction_timestamp'], errors='coerce')
        
        # Замена \N на NaN
        df = df.replace('\\N', pd.NA)
        
        # Индексация для ускорения поиска
        if 'transaction_timestamp' in df.columns:
            df = df.sort_values('transaction_timestamp', ascending=False).reset_index(drop=True)
        
        # Сброс кэша
        stats_cache = None
        cache_timestamp = None
        
        logger.info(f"Загружено {len(df)} транзакций")
        return True
    except Exception as e:
        logger.error(f"Ошибка при загрузке данных: {e}")
        return False

def get_available_categories():
    """Получение списка доступных категорий для промпта"""
    global df
    if df is None:
        return "Grocery & Food Markets, Utilities & Bill Payments, Pharmacies & Health, General Retail & Department"
    try:
        categories = df['mcc_category'].dropna().unique()[:20]  # Первые 20 категорий
        return ", ".join([f'"{cat}"' for cat in categories])
    except:
        return "Grocery & Food Markets, Utilities & Bill Payments, Pharmacies & Health, General Retail & Department"

async def get_ai_analysis(user_message: str, context: str = "") -> str:
    """Получение анализа от ИИ через OpenRouter API для режима чата"""
    if not OPENROUTER_API_KEY:
        return None
    
    try:
        system_prompt = """Ты - эксперт по анализу финансовых транзакций Mastercard. Отвечай кратко и по делу на русском языке с эмодзи."""
        
        user_prompt = f"""Вопрос: "{user_message}"\n\nКонтекст: {context}\n\nКраткий ответ:"""
        
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ]
        
        async with httpx.AsyncClient(timeout=5.0) as client:
            response = await client.post(
                OPENROUTER_API_URL,
                headers={
                    "Authorization": f"Bearer {OPENROUTER_API_KEY}",
                    "Content-Type": "application/json"
                },
                json={
                    "model": OPENROUTER_MODEL,
                    "messages": messages,
                    "temperature": 0.7,
                    "max_tokens": 500,
                    "stream": False
                }
            )
            
            if response.status_code == 200:
                result = response.json()
                content = result.get('choices', [{}])[0].get('message', {}).get('content', '').strip()
                return content
            else:
                logger.error(f"Ошибка OpenRouter API: {response.status_code}")
                return None
                
    except Exception as e:
        logger.error(f"Ошибка при запросе к ИИ: {e}")
        return None

async def get_ai_response(user_message: str, context: str = "") -> dict:
    """Получение ответа от ИИ через OpenRouter API"""
    if not OPENROUTER_API_KEY:
        logger.warning("OPENROUTER_API_KEY не установлен, ИИ функции отключены")
        return None
    
    try:
        categories_list = get_available_categories()
        
        system_prompt = f"""Ты - эксперт по анализу транзакций Mastercard. Твоя задача - понять вопрос пользователя на русском языке и преобразовать его в структурированный JSON запрос.

ВАЖНЫЕ ПРАВИЛА:
1. ВСЕГДА возвращай ТОЛЬКО валидный JSON без дополнительного текста
2. Используй точные значения полей из базы данных
3. Для категорий используй ТОЧНОЕ значение из списка (с заглавными буквами и амперсандами)
4. Для городов используй: "Almaty", "Shymkent", "Astana" (ТОЧНО так!)
5. Для типов транзакций: "POS", "ECOM", "BILL_PAYMENT"
6. Для способов оплаты: "Apple Pay", "Samsung Pay", "Bank's QR"
7. Даты в формате "YYYY-MM-DD" (например: "2023-08-01")

ДОСТУПНЫЕ КАТЕГОРИИ (используй ТОЧНОЕ значение):
{categories_list}

ПОЛЯ В БАЗЕ ДАННЫХ:
- transaction_timestamp: дата и время (формат: YYYY-MM-DD или YYYY-MM-DD HH:MM:SS)
- transaction_amount_kzt: сумма в тенге (число)
- mcc_category: категория (точное значение из списка выше)
- merchant_city: город ("Almaty", "Shymkent", "Astana")
- transaction_type: тип ("POS" - офлайн оплата, "ECOM" - онлайн, "BILL_PAYMENT" - платежи по счетам)
- wallet_type: способ ("Apple Pay", "Samsung Pay", "Bank's QR")

ТИПЫ ЗАПРОСОВ:
- "stats" - статистика (количество, сумма, среднее)
- "top" - топ N самых больших/маленьких транзакций
- "last" - последние N транзакций
- "filter" - фильтрация с показом деталей

МАППИНГ РУССКИХ СЛОВ:
- "продуктовые", "продукты", "магазин продуктов" → "Grocery & Food Markets"
- "коммуналка", "коммунальные", "счета" → "Utilities & Bill Payments"
- "аптека", "лекарства", "здоровье" → "Pharmacies & Health"
- "магазин", "ритейл" → "General Retail & Department"
- "август", "авг" → месяц 8 (start_date: "2023-08-01", end_date: "2023-08-31")
- "сентябрь" → месяц 9, "октябрь" → 10, "ноябрь" → 11, "декабрь" → 12
- "алматы", "алма-ата" → "Almaty"
- "шымкент" → "Shymkent"
- "астана", "нур-султан" → "Astana"
- "больше", "от", "минимум", ">" → min_amount
- "меньше", "до", "максимум", "<" → max_amount
- "онлайн", "интернет", "ecom" → "ECOM"
- "офлайн", "магазин", "pos" → "POS"
- "платеж", "счет", "bill" → "BILL_PAYMENT"

ФОРМАТ JSON (ВСЕГДА ВОЗВРАЩАЙ ТОЛЬКО ЭТО):
{{
  "query_type": "stats|top|last|filter",
  "filters": {{
    "category": "точное значение из списка" или null,
    "city": "Almaty|Shymkent|Astana" или null,
    "transaction_type": "POS|ECOM|BILL_PAYMENT" или null,
    "wallet_type": "Apple Pay|Samsung Pay|Bank's QR" или null,
    "min_amount": число или null,
    "max_amount": число или null,
    "start_date": "YYYY-MM-DD" или null,
    "end_date": "YYYY-MM-DD" или null
  }},
  "limit": число (если нужно ограничить) или null,
  "sort_by": "amount|date" или null,
  "sort_order": "desc|asc" или null,
  "human_readable": "краткое описание запроса на русском"
}}

ПРИМЕРЫ:

Вопрос: "Сколько потратил в продуктовых в августе 2023?"
Ответ: {{"query_type": "stats", "filters": {{"category": "Grocery & Food Markets", "start_date": "2023-08-01", "end_date": "2023-08-31"}}, "human_readable": "Статистика по категории 'Продуктовые магазины' за август 2023"}}

Вопрос: "Покажи топ 5 самых больших трат в Алматы"
Ответ: {{"query_type": "top", "filters": {{"city": "Almaty"}}, "limit": 5, "sort_by": "amount", "sort_order": "desc", "human_readable": "Топ-5 самых больших транзакций в Алматы"}}

Вопрос: "Транзакции больше 10000 тенге через Apple Pay"
Ответ: {{"query_type": "filter", "filters": {{"min_amount": 10000, "wallet_type": "Apple Pay"}}, "human_readable": "Транзакции от 10000 тенге через Apple Pay"}}

Вопрос: "Сколько потратил в аптеках через онлайн в октябре?"
Ответ: {{"query_type": "stats", "filters": {{"category": "Pharmacies & Health", "transaction_type": "ECOM", "start_date": "2023-10-01", "end_date": "2023-10-31"}}, "human_readable": "Статистика по аптекам (онлайн) за октябрь 2023"}}

Вопрос: "Траты от 5000 до 20000 в Шымкенте"
Ответ: {{"query_type": "filter", "filters": {{"min_amount": 5000, "max_amount": 20000, "city": "Shymkent"}}, "human_readable": "Транзакции от 5000 до 20000 тенге в Шымкенте"}}

Вопрос: "Последние 10 транзакций"
Ответ: {{"query_type": "last", "filters": {{}}, "limit": 10, "sort_by": "date", "sort_order": "desc", "human_readable": "Последние 10 транзакций"}}

ПОМНИ: Возвращай ТОЛЬКО JSON, никаких пояснений до или после!"""

        user_prompt = f"""Пользователь спросил: "{user_message}"

{context if context else ""}

Преобразуй этот вопрос в JSON запрос согласно правилам выше. Верни ТОЛЬКО JSON без дополнительного текста."""

        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ]
        
        async with httpx.AsyncClient(timeout=5.0) as client:
            response = await client.post(
                OPENROUTER_API_URL,
                headers={
                    "Authorization": f"Bearer {OPENROUTER_API_KEY}",
                    "Content-Type": "application/json",
                    "HTTP-Referer": "https://github.com/your-repo",  # Опционально
                    "X-Title": "Transaction Bot"  # Опционально
                },
                json={
                    "model": OPENROUTER_MODEL,
                    "messages": messages,
                    "temperature": 0.1,  # Низкая температура для более точных ответов
                    "max_tokens": 800,  # Увеличил для более детальных ответов
                    "top_p": 0.9,
                    "frequency_penalty": 0.3,
                    "presence_penalty": 0.3
                }
            )
            
            if response.status_code == 200:
                result = response.json()
                content = result.get('choices', [{}])[0].get('message', {}).get('content', '').strip()
                
                # Улучшенная обработка ответа - убираем markdown код блоки
                content = re.sub(r'```json\s*', '', content)
                content = re.sub(r'```\s*', '', content)
                content = content.strip()
                
                # Извлекаем JSON из ответа
                json_match = re.search(r'\{.*\}', content, re.DOTALL)
                if json_match:
                    try:
                        parsed_json = json.loads(json_match.group())
                        logger.info(f"ИИ вернул: {parsed_json.get('human_readable', 'N/A')}")
                        return parsed_json
                    except json.JSONDecodeError as e:
                        logger.error(f"Ошибка парсинга JSON от ИИ: {e}, содержимое: {content[:200]}")
                        return None
                else:
                    logger.warning(f"ИИ не вернул JSON, содержимое: {content[:200]}")
                    return None
            else:
                logger.error(f"Ошибка OpenRouter API: {response.status_code} - {response.text}")
                return None
                
    except Exception as e:
        logger.error(f"Ошибка при запросе к ИИ: {e}")
        return None

def execute_ai_query(query_data: dict) -> str:
    """Выполнение запроса на основе данных от ИИ (оптимизировано)"""
    global df
    if df is None or not query_data:
        return "❌ Ошибка: данные не загружены или запрос некорректен"
    
    try:
        filters = query_data.get('filters', {})
        
        # Создаем маску для всех фильтров сразу (быстрее чем множественные copy)
        mask = pd.Series([True] * len(df), index=df.index)
        
        if filters.get('category'):
            mask &= (df['mcc_category'] == filters['category'])
        
        if filters.get('city'):
            mask &= (df['merchant_city'] == filters['city'])
        
        if filters.get('transaction_type'):
            mask &= (df['transaction_type'] == filters['transaction_type'])
        
        if filters.get('wallet_type'):
            mask &= (df['wallet_type'] == filters['wallet_type'])
        
        if filters.get('min_amount'):
            mask &= (df['transaction_amount_kzt'] >= filters['min_amount'])
        
        if filters.get('max_amount'):
            mask &= (df['transaction_amount_kzt'] <= filters['max_amount'])
        
        if filters.get('start_date'):
            start_date = pd.to_datetime(filters['start_date'])
            mask &= (df['transaction_timestamp'] >= start_date)
        
        if filters.get('end_date'):
            end_date = pd.to_datetime(filters['end_date'])
            mask &= (df['transaction_timestamp'] <= end_date)
        
        # Применяем все фильтры сразу
        filtered_df = df[mask]
        
        query_type = query_data.get('query_type', 'stats')
        limit = query_data.get('limit')
        sort_by = query_data.get('sort_by')
        sort_order = query_data.get('sort_order', 'desc')
        
        # Сортировка
        if sort_by == 'amount':
            filtered_df = filtered_df.sort_values('transaction_amount_kzt', ascending=(sort_order == 'asc'))
        elif sort_by == 'date':
            filtered_df = filtered_df.sort_values('transaction_timestamp', ascending=(sort_order == 'asc'))
        
        # Формируем ответ в зависимости от типа запроса
        if query_type == 'stats':
            total = filtered_df['transaction_amount_kzt'].sum()
            count = len(filtered_df)
            avg = filtered_df['transaction_amount_kzt'].mean()
            
            response = f"📊 {query_data.get('human_readable', 'Статистика')}:\n\n"
            response += f"• Всего транзакций: {count:,}\n"
            response += f"• Общая сумма: {total:,.2f} KZT\n"
            response += f"• Средняя сумма: {avg:,.2f} KZT\n"
            if count > 0:
                response += f"• Минимум: {filtered_df['transaction_amount_kzt'].min():,.2f} KZT\n"
                response += f"• Максимум: {filtered_df['transaction_amount_kzt'].max():,.2f} KZT\n"
            return response
        
        elif query_type == 'top':
            n = limit or 10
            n = min(n, 20)
            top_df = filtered_df.head(n)
            
            # Используем itertuples вместо iterrows (в 100 раз быстрее)
            lines = [f"🏆 {query_data.get('human_readable', f'ТОП-{n} транзакций')}:\n\n"]
            for row in top_df.itertuples(index=False):
                date = row.transaction_timestamp.strftime('%d.%m.%Y %H:%M') if pd.notna(row.transaction_timestamp) else 'N/A'
                amount = row.transaction_amount_kzt
                category = row.mcc_category if pd.notna(row.mcc_category) else 'N/A'
                city = row.merchant_city if pd.notna(row.merchant_city) else 'N/A'
                lines.append(f"💰 {amount:,.2f} KZT\n   📅 {date} | 📍 {city}\n   🏷️ {category}\n\n")
            return ''.join(lines)
        
        elif query_type == 'last':
            n = limit or 10
            n = min(n, 20)
            last_df = filtered_df.tail(n)
            
            # Используем itertuples вместо iterrows
            lines = [f"📋 {query_data.get('human_readable', f'Последние {n} транзакций')}:\n\n"]
            for row in last_df.itertuples(index=False):
                date = row.transaction_timestamp.strftime('%d.%m.%Y %H:%M') if pd.notna(row.transaction_timestamp) else 'N/A'
                amount = row.transaction_amount_kzt
                category = row.mcc_category if pd.notna(row.mcc_category) else 'N/A'
                city = row.merchant_city if pd.notna(row.merchant_city) else 'N/A'
                lines.append(f"💰 {amount:,.2f} KZT\n   📅 {date}\n   📍 {city} | {category}\n\n")
            return ''.join(lines)
        
        elif query_type == 'filter':
            total = filtered_df['transaction_amount_kzt'].sum()
            count = len(filtered_df)
            
            response = f"🔍 {query_data.get('human_readable', 'Результаты фильтрации')}:\n\n"
            response += f"• Найдено транзакций: {count:,}\n"
            response += f"• Общая сумма: {total:,.2f} KZT\n"
            
            if count > 0 and count <= 10:
                # Показываем детали если немного транзакций (используем itertuples)
                lines = [response, "\nДетали:\n"]
                for row in filtered_df.itertuples(index=False):
                    date = row.transaction_timestamp.strftime('%d.%m.%Y %H:%M') if pd.notna(row.transaction_timestamp) else 'N/A'
                    amount = row.transaction_amount_kzt
                    category = row.mcc_category if pd.notna(row.mcc_category) else 'N/A'
                    city = row.merchant_city if pd.notna(row.merchant_city) else 'N/A'
                    lines.append(f"💰 {amount:,.2f} KZT | {date} | {city} | {category}\n")
                return ''.join(lines)
            
            return response
        
        else:
            # По умолчанию статистика
            total = filtered_df['transaction_amount_kzt'].sum()
            count = len(filtered_df)
            response = f"📊 Найдено: {count:,} транзакций на сумму {total:,.2f} KZT"
            return response
            
    except Exception as e:
        logger.error(f"Ошибка при выполнении запроса: {e}")
        return f"❌ Ошибка при обработке запроса: {e}"

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик команды /start"""
    # Кнопки как на фото: Дашборд, Быстрые запросы, История, Избранное
    keyboard = [
        [
            InlineKeyboardButton("📊 Дашборд", callback_data="menu_dashboard"),
            InlineKeyboardButton("⚡ Быстрые запросы", callback_data="menu_quick")
        ],
        [
            InlineKeyboardButton("📋 История", callback_data="menu_history"),
            InlineKeyboardButton("⭐ Избранное", callback_data="menu_favorites")
        ],
        [
            InlineKeyboardButton("🤖 Чат с ИИ", callback_data="menu_ai_chat"),
            InlineKeyboardButton("📈 Статистика", callback_data="menu_stats")
        ],
        [
            InlineKeyboardButton("🔄 Сравнить", callback_data="menu_compare"),
            InlineKeyboardButton("💾 Экспорт", callback_data="menu_export")
        ],
        [
            InlineKeyboardButton("🔍 Фильтры", callback_data="menu_filters"),
            InlineKeyboardButton("❓ Помощь", callback_data="menu_help")
        ]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    welcome_message = """
🤖 Добро пожаловать в бот анализа транзакций Mastercard!

📊 Быстрый доступ:
• 📊 Дашборд - графики и визуализация
• ⚡ Быстрые запросы - популярные действия
• 📋 История - ваши запросы
• ⭐ Избранное - сохраненные результаты
• 🤖 Чат с ИИ - анализ данных через ИИ

💬 Или задайте вопрос естественным языком!
Можете также отправить CSV/Excel файл для анализа."""
    await update.message.reply_text(welcome_message, reply_markup=reply_markup)

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик команды /help"""
    help_text = """
📊 Анализ транзакций Mastercard

Примеры вопросов:
• Общая статистика: "Статистика", "/stats"
• По датам: "Траты за август 2023", "Транзакции в сентябре"
• По категориям: "Категории", "Суммы по категориям"
• По городам: "Траты в Алматы", "Шымкент"
• По типу: "Онлайн покупки", "POS транзакции"
• Топ транзакции: "Самые большие траты", "Топ 10"
• Последние: "Последние 5 транзакций", "Недавние покупки"
• По банку: "Транзакции My Favorite Bank"
• По способу оплаты: "Apple Pay", "QR код"
"""
    await update.message.reply_text(help_text)

async def stats_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик команды /stats - общая статистика"""
    if df is None:
        await update.message.reply_text("❌ Данные не загружены. Проверьте наличие CSV файла.")
        return
    
    try:
        total_transactions = len(df)
        total_amount = df['transaction_amount_kzt'].sum()
        avg_amount = df['transaction_amount_kzt'].mean()
        
        # Статистика по категориям
        category_stats = df.groupby('mcc_category')['transaction_amount_kzt'].sum().sort_values(ascending=False)
        top_categories = category_stats.head(5)
        
        # Статистика по городам
        city_stats = df.groupby('merchant_city')['transaction_amount_kzt'].sum().sort_values(ascending=False)
        top_cities = city_stats.head(5)
        
        # Даты
        min_date = df['transaction_timestamp'].min()
        max_date = df['transaction_timestamp'].max()
        
        # Типы транзакций
        transaction_types = df['transaction_type'].value_counts()
        
        # Используем список и join для быстрого создания строки
        lines = [
            "📊 ОБЩАЯ СТАТИСТИКА\n\n",
            "💰 Финансы:\n",
            f"• Всего транзакций: {total_transactions:,}\n",
            f"• Общая сумма: {total_amount:,.2f} KZT\n",
            f"• Средняя сумма: {avg_amount:,.2f} KZT\n\n",
            "📅 Период:\n",
            f"• С {min_date.strftime('%d.%m.%Y') if pd.notna(min_date) else 'N/A'}\n",
            f"• По {max_date.strftime('%d.%m.%Y') if pd.notna(max_date) else 'N/A'}\n\n",
            "🏆 ТОП-5 категорий:\n"
        ]
        for category, amount in top_categories.items():
            lines.append(f"• {category}: {amount:,.2f} KZT\n")
        
        lines.append("\n🌍 ТОП-5 городов:\n")
        for city, amount in top_cities.items():
            lines.append(f"• {city}: {amount:,.2f} KZT\n")
        
        lines.append("\n💳 Типы транзакций:\n")
        for trans_type, count in transaction_types.items():
            lines.append(f"• {trans_type}: {count}\n")
        
        stats_text = ''.join(lines)
        
        # Сохраняем в кэш
        now = datetime.now().timestamp()
        stats_cache = stats_text
        cache_timestamp = now
        
        # Добавляем кнопки быстрого доступа
        keyboard = [
            [
                InlineKeyboardButton("📈 Графики", callback_data="menu_dashboard"),
                InlineKeyboardButton("🔄 Сравнить", callback_data="menu_compare")
            ],
            [
                InlineKeyboardButton("💾 Экспорт", callback_data="menu_export"),
                InlineKeyboardButton("🏠 Меню", callback_data="menu_main")
            ]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await update.message.reply_text(stats_text, reply_markup=reply_markup)
        
    except Exception as e:
        logger.error(f"Ошибка в stats: {e}")
        await update.message.reply_text(f"❌ Ошибка при формировании статистики: {e}")

async def handle_file(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка загруженных файлов"""
    global df
    user_id = update.effective_user.id
    
    try:
        document = update.message.document
        if not document:
            await update.message.reply_text("❌ Файл не найден.")
            return
        
        file = await context.bot.get_file(document.file_id)
        filename = document.file_name.lower()
        
        # Создаем временный файл
        temp_file = io.BytesIO()
        await file.download_to_memory(temp_file)
        temp_file.seek(0)
        
        # Загружаем данные в зависимости от типа файла
        if filename.endswith('.csv'):
            new_df = pd.read_csv(temp_file, low_memory=False)
            success = True
        elif filename.endswith(('.xlsx', '.xls')):
            new_df = pd.read_excel(temp_file, engine='openpyxl' if filename.endswith('.xlsx') else None)
            success = True
        else:
            await update.message.reply_text("❌ Поддерживаются только CSV и Excel файлы.")
            return
        
        if success:
            # Преобразуем timestamp если есть
            if 'transaction_timestamp' in new_df.columns:
                new_df['transaction_timestamp'] = pd.to_datetime(new_df['transaction_timestamp'], errors='coerce')
            new_df = new_df.replace('\\N', pd.NA)
            
            # Сортируем по дате для ускорения последующих запросов
            if 'transaction_timestamp' in new_df.columns:
                new_df = new_df.sort_values('transaction_timestamp', ascending=False).reset_index(drop=True)
            
            # Обновляем глобальный DataFrame и сбрасываем кэш
            global stats_cache, cache_timestamp
            df = new_df
            stats_cache = None
            cache_timestamp = None
            
            keyboard = [
                [InlineKeyboardButton("📊 Дашборд", callback_data="menu_dashboard")],
                [InlineKeyboardButton("📈 Статистика", callback_data="menu_stats")]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await update.message.reply_text(
                f"✅ Файл успешно загружен!\n\nЗагружено {len(df)} транзакций.\n\nТеперь можно анализировать данные!",
                reply_markup=reply_markup
            )
        
        temp_file.close()
        
    except Exception as e:
        logger.error(f"Ошибка при загрузке файла: {e}")
        await update.message.reply_text(f"❌ Ошибка при загрузке файла: {e}")

async def analyze_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Анализ сообщения пользователя и формирование ответа"""
    global df
    user_id = update.effective_user.id
    
    # Проверяем режим чата с ИИ
    is_ai_chat = ai_chat_mode.get(user_id, False)
    
    if df is None:
        await update.message.reply_text("❌ Данные не загружены. Проверьте наличие CSV файла или отправьте файл для анализа.")
        return
    
    user_message = update.message.text
    user_message_lower = user_message.lower()
    response = ""
    
    try:
        # Сохраняем запрос в историю
        if user_id not in user_history:
            user_history[user_id] = []
        user_history[user_id].append({
            'query': user_message,
            'timestamp': datetime.now().strftime('%d.%m.%Y %H:%M')
        })
        
        # Если включен режим чата с ИИ, используем ИИ (только один раз)
        if is_ai_chat:
            # Создаем контекст для ИИ
            summary = f"Всего транзакций: {len(df)}, Общая сумма: {df['transaction_amount_kzt'].sum():,.2f} KZT"
            
            # Используем ИИ для анализа (быстрый timeout)
            ai_response = await get_ai_analysis(user_message, summary)
            if ai_response:
                response = f"🤖 {ai_response}"
            else:
                # Fallback на быструю обработку если ИИ не ответил
                response = "❓ Не удалось проанализировать запрос. Попробуйте переформулировать или используйте быстрые запросы."
        
        # Обычный режим - сначала быстрая обработка, ИИ только для сложных
        else:
            # Сначала проверяем простые паттерны (БЫСТРО)
            # Поиск по датам
            if any(word in user_message_lower for word in ['август', 'сентябрь', 'октябрь', 'ноябрь', 'декабрь']):
                month_map = {
                    'август': 8, 'сентябрь': 9, 'октябрь': 10,
                    'ноябрь': 11, 'декабрь': 12
                }
                year = None
                if '2023' in user_message:
                    year = 2023
                elif '2024' in user_message:
                    year = 2024
                
                for month_name, month_num in month_map.items():
                    if month_name in user_message_lower:
                        filtered = df[df['transaction_timestamp'].dt.month == month_num]
                        if year:
                            filtered = filtered[filtered['transaction_timestamp'].dt.year == year]
                        
                        total = filtered['transaction_amount_kzt'].sum()
                        count = len(filtered)
                        response = f"📅 {month_name.capitalize()}{(' ' + str(year)) if year else ''}:\n"
                        response += f"• Транзакций: {count:,}\n"
                        response += f"• Общая сумма: {total:,.2f} KZT\n"
                        break
            
            # Последние N транзакций
            elif any(word in user_message_lower for word in ['последние', 'недавние', 'недавно']):
                numbers = re.findall(r'\d+', user_message)
                n = int(numbers[0]) if numbers else 5
                n = min(n, 20)  # Максимум 20
                
                # Уже отсортировано при загрузке, берем первые n
                last_transactions = df.head(n)
                lines = [f"📋 Последние {n} транзакций:\n\n"]
                for row in last_transactions.itertuples(index=False):
                    date = row.transaction_timestamp.strftime('%d.%m.%Y %H:%M') if pd.notna(row.transaction_timestamp) else 'N/A'
                    amount = row.transaction_amount_kzt
                    category = row.mcc_category if pd.notna(row.mcc_category) else 'N/A'
                    city = row.merchant_city if pd.notna(row.merchant_city) else 'N/A'
                    lines.append(f"💰 {amount:,.2f} KZT\n   📅 {date}\n   📍 {city} | {category}\n\n")
                response = ''.join(lines)
            
            # Категории и суммы
            elif any(word in user_message_lower for word in ['категори', 'сумма по категориям']):
                category_stats = df.groupby('mcc_category')['transaction_amount_kzt'].agg(['sum', 'count']).sort_values('sum', ascending=False)
                lines = ["📊 Суммы по категориям:\n\n"]
                for category, row in category_stats.items():
                    lines.append(f"🏷️ {category}\n   💰 {row['sum']:,.2f} KZT ({row['count']} транзакций)\n\n")
                response = ''.join(lines)
            
            # Топ транзакций
            elif any(word in user_message_lower for word in ['топ', 'самые большие', 'большие траты', 'максимальные']):
                numbers = re.findall(r'\d+', user_message)
                n = int(numbers[0]) if numbers else 10
                n = min(n, 20)
                
                top_transactions = df.nlargest(n, 'transaction_amount_kzt')
                lines = [f"🏆 ТОП-{n} самых больших транзакций:\n\n"]
                for row in top_transactions.itertuples(index=False):
                    date = row.transaction_timestamp.strftime('%d.%m.%Y %H:%M') if pd.notna(row.transaction_timestamp) else 'N/A'
                    amount = row.transaction_amount_kzt
                    category = row.mcc_category if pd.notna(row.mcc_category) else 'N/A'
                    city = row.merchant_city if pd.notna(row.merchant_city) else 'N/A'
                    lines.append(f"💰 {amount:,.2f} KZT\n   📅 {date} | 📍 {city}\n   🏷️ {category}\n\n")
                response = ''.join(lines)
            
            # По городам
            elif any(word in user_message_lower for word in ['алматы', 'шымкент', 'астана']):
                city_map = {
                    'алматы': 'Almaty',
                    'шымкент': 'Shymkent',
                    'астана': 'Astana'
                }
                city_filter = None
                for ru_name, en_name in city_map.items():
                    if ru_name in user_message_lower:
                        city_filter = en_name
                        break
                
                if city_filter:
                    filtered = df[df['merchant_city'] == city_filter]
                    total = filtered['transaction_amount_kzt'].sum()
                    count = len(filtered)
                    avg = filtered['transaction_amount_kzt'].mean()
                    
                    response = f"🌍 Транзакции в {city_filter}:\n"
                    response += f"• Всего: {count:,} транзакций\n"
                    response += f"• Общая сумма: {total:,.2f} KZT\n"
                    response += f"• Средняя: {avg:,.2f} KZT\n"
                    
                    # Топ категорий в городе
                    city_categories = filtered.groupby('mcc_category')['transaction_amount_kzt'].sum().sort_values(ascending=False).head(5)
                    response += "\n🏆 ТОП категорий:\n"
                    for cat, amt in city_categories.items():
                        response += f"• {cat}: {amt:,.2f} KZT\n"
            
            # По типу транзакции
            elif any(word in user_message_lower for word in ['pos', 'онлайн', 'ecom', 'bill', 'платеж']):
                if 'pos' in user_message_lower or 'офлайн' in user_message_lower:
                    filtered = df[df['transaction_type'] == 'POS']
                elif 'ecom' in user_message_lower or 'онлайн' in user_message_lower:
                    filtered = df[df['transaction_type'] == 'ECOM']
                elif 'bill' in user_message_lower or 'платеж' in user_message_lower or 'счет' in user_message_lower:
                    filtered = df[df['transaction_type'] == 'BILL_PAYMENT']
                else:
                    filtered = df
                
                total = filtered['transaction_amount_kzt'].sum()
                count = len(filtered)
                response = f"💳 {filtered['transaction_type'].iloc[0] if len(filtered) > 0 else 'N/A'}:\n"
                response += f"• Транзакций: {count:,}\n"
                response += f"• Общая сумма: {total:,.2f} KZT\n"
            
            # По способу оплаты (wallet_type)
            elif any(word in user_message_lower for word in ['apple pay', 'samsung pay', 'qr', 'контакт']):
                if 'apple pay' in user_message_lower:
                    filtered = df[df['wallet_type'] == 'Apple Pay']
                elif 'samsung pay' in user_message_lower:
                    filtered = df[df['wallet_type'] == 'Samsung Pay']
                elif 'qr' in user_message_lower:
                    filtered = df[df['wallet_type'].str.contains('QR', case=False, na=False)]
                elif 'контакт' in user_message_lower:
                    filtered = df[df['pos_entry_mode'] == 'Contactless']
                else:
                    filtered = df
                
                if len(filtered) > 0:
                    total = filtered['transaction_amount_kzt'].sum()
                    count = len(filtered)
                    wallet = filtered['wallet_type'].iloc[0] if pd.notna(filtered['wallet_type'].iloc[0]) else 'Contactless'
                    response = f"💳 {wallet}:\n"
                    response += f"• Транзакций: {count:,}\n"
                    response += f"• Общая сумма: {total:,.2f} KZT\n"
            
            # Общая статистика по запросу
            elif any(word in user_message_lower for word in ['статистика', 'общая', 'итого', 'сколько потратил', 'общее']):
                total_amount = df['transaction_amount_kzt'].sum()
                total_count = len(df)
                avg_amount = df['transaction_amount_kzt'].mean()
                
                response = f"📊 Общая статистика:\n"
                response += f"• Всего транзакций: {total_count:,}\n"
                response += f"• Общая сумма: {total_amount:,.2f} KZT\n"
                response += f"• Средняя сумма: {avg_amount:,.2f} KZT\n"
                response += f"• Минимум: {df['transaction_amount_kzt'].min():,.2f} KZT\n"
                response += f"• Максимум: {df['transaction_amount_kzt'].max():,.2f} KZT\n"
            
            # Если не распознано - используем ИИ только для сложных запросов
            else:
                # ИИ только для сложных запросов (с коротким timeout)
                try:
                    ai_query = await get_ai_response(user_message)
                    if ai_query:
                        response = execute_ai_query(ai_query)
                    else:
                        response = "❓ Не понял вопрос. Используйте кнопки быстрого доступа."
                except:
                    response = "❓ Не понял вопрос. Используйте кнопки быстрого доступа."
        
        # Отправка ОДНОГО ответа с кнопками быстрого доступа
        if response:  # Проверяем, что есть ответ
            keyboard = [
                [
                    InlineKeyboardButton("📊 График", callback_data="menu_dashboard"),
                    InlineKeyboardButton("📈 Статистика", callback_data="menu_stats")
                ],
                [
                    InlineKeyboardButton("⭐ В избранное", callback_data="favorite_add"),
                    InlineKeyboardButton("💾 Экспорт", callback_data="menu_export")
                ],
                [InlineKeyboardButton("🏠 Меню", callback_data="menu_main")]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            if len(response) > 4096:
                # Разбиваем на части (только если очень длинный)
                parts = [response[i:i+4000] for i in range(0, len(response), 4000)]
                for i, part in enumerate(parts):
                    if i == len(parts) - 1:  # Последняя часть с кнопками
                        await update.message.reply_text(part, reply_markup=reply_markup)
                    else:
                        await update.message.reply_text(part)
            else:
                # Отправляем ОДИН ответ
                await update.message.reply_text(response, reply_markup=reply_markup)
        else:
            # Если нет ответа, отправляем подсказку
            await update.message.reply_text("❓ Не понял вопрос. Используйте кнопки быстрого доступа или переформулируйте запрос.")
            
    except Exception as e:
        logger.error(f"Ошибка при анализе: {e}")
        await update.message.reply_text(f"❌ Ошибка: {e}")

# Функции для генерации графиков
def create_category_chart(filtered_df=None):
    """Создание графика по категориям"""
    data = filtered_df if filtered_df is not None else df
    category_stats = data.groupby('mcc_category')['transaction_amount_kzt'].sum().sort_values(ascending=False).head(10)
    
    plt.figure(figsize=(12, 6))
    category_stats.plot(kind='barh', color='steelblue')
    plt.title('ТОП-10 категорий по сумме транзакций', fontsize=14, fontweight='bold')
    plt.xlabel('Сумма (KZT)', fontsize=12)
    plt.ylabel('Категория', fontsize=12)
    plt.gca().invert_yaxis()
    plt.tight_layout()
    
    buf = io.BytesIO()
    plt.savefig(buf, format='png', dpi=150, bbox_inches='tight')
    buf.seek(0)
    plt.close()
    return buf

def create_city_chart(filtered_df=None):
    """Создание графика по городам"""
    data = filtered_df if filtered_df is not None else df
    city_stats = data.groupby('merchant_city')['transaction_amount_kzt'].sum().sort_values(ascending=False)
    
    plt.figure(figsize=(10, 6))
    city_stats.plot(kind='bar', color='coral')
    plt.title('Сумма транзакций по городам', fontsize=14, fontweight='bold')
    plt.xlabel('Город', fontsize=12)
    plt.ylabel('Сумма (KZT)', fontsize=12)
    plt.xticks(rotation=45)
    plt.tight_layout()
    
    buf = io.BytesIO()
    plt.savefig(buf, format='png', dpi=150, bbox_inches='tight')
    buf.seek(0)
    plt.close()
    return buf

def create_timeline_chart(filtered_df=None):
    """Создание графика динамики по времени"""
    data = filtered_df if filtered_df is not None else df
    data['date'] = pd.to_datetime(data['transaction_timestamp']).dt.date
    daily_stats = data.groupby('date')['transaction_amount_kzt'].sum().sort_index()
    
    plt.figure(figsize=(14, 6))
    plt.plot(daily_stats.index, daily_stats.values, marker='o', linewidth=2, markersize=4)
    plt.title('Динамика транзакций по дням', fontsize=14, fontweight='bold')
    plt.xlabel('Дата', fontsize=12)
    plt.ylabel('Сумма (KZT)', fontsize=12)
    plt.grid(True, alpha=0.3)
    plt.xticks(rotation=45)
    plt.tight_layout()
    
    buf = io.BytesIO()
    plt.savefig(buf, format='png', dpi=150, bbox_inches='tight')
    buf.seek(0)
    plt.close()
    return buf

def create_pie_chart_categories(filtered_df=None):
    """Круговая диаграмма по категориям"""
    data = filtered_df if filtered_df is not None else df
    category_stats = data.groupby('mcc_category')['transaction_amount_kzt'].sum().sort_values(ascending=False).head(8)
    
    plt.figure(figsize=(10, 8))
    plt.pie(category_stats.values, labels=category_stats.index, autopct='%1.1f%%', startangle=90)
    plt.title('Распределение транзакций по категориям', fontsize=14, fontweight='bold')
    plt.tight_layout()
    
    buf = io.BytesIO()
    plt.savefig(buf, format='png', dpi=150, bbox_inches='tight')
    buf.seek(0)
    plt.close()
    return buf

# Команды с графиками
async def dashboard_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Команда /dashboard - графики и визуализация"""
    if df is None:
        await update.message.reply_text("❌ Данные не загружены.")
        return
    
    keyboard = [
        [
            InlineKeyboardButton("📊 По категориям", callback_data="chart_categories"),
            InlineKeyboardButton("🏙️ По городам", callback_data="chart_cities")
        ],
        [
            InlineKeyboardButton("📈 Временная динамика", callback_data="chart_timeline"),
            InlineKeyboardButton("🥧 Круговая (категории)", callback_data="chart_pie")
        ],
        [InlineKeyboardButton("🔙 Назад", callback_data="menu_main")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(
        "📊 Выберите тип графика:",
        reply_markup=reply_markup
    )

async def compare_periods_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Команда /compare - сравнение периодов"""
    if df is None:
        await update.message.reply_text("❌ Данные не загружены.")
        return
    
    # Получаем два последних месяца
    max_date = df['transaction_timestamp'].max()
    min_date = df['transaction_timestamp'].min()
    
    # Разделяем на два периода (первая и вторая половина данных)
    mid_date = min_date + (max_date - min_date) / 2
    
    period1 = df[df['transaction_timestamp'] <= mid_date]
    period2 = df[df['transaction_timestamp'] > mid_date]
    
    p1_total = period1['transaction_amount_kzt'].sum()
    p1_count = len(period1)
    p1_avg = period1['transaction_amount_kzt'].mean()
    
    p2_total = period2['transaction_amount_kzt'].sum()
    p2_count = len(period2)
    p2_avg = period2['transaction_amount_kzt'].mean()
    
    # Процентные изменения
    change_total = ((p2_total - p1_total) / p1_total * 100) if p1_total > 0 else 0
    change_count = ((p2_count - p1_count) / p1_count * 100) if p1_count > 0 else 0
    change_avg = ((p2_avg - p1_avg) / p1_avg * 100) if p1_avg > 0 else 0
    
    comparison = f"""
🔄 СРАВНЕНИЕ ПЕРИОДОВ

📅 Период 1: {min_date.strftime('%d.%m.%Y')} - {mid_date.strftime('%d.%m.%Y')}
📅 Период 2: {mid_date.strftime('%d.%m.%Y')} - {max_date.strftime('%d.%m.%Y')}

💰 Сумма:
• Период 1: {p1_total:,.2f} KZT
• Период 2: {p2_total:,.2f} KZT
• Изменение: {change_total:+.1f}% {'📈' if change_total > 0 else '📉'}

📊 Количество:
• Период 1: {p1_count:,} транзакций
• Период 2: {p2_count:,} транзакций
• Изменение: {change_count:+.1f}% {'📈' if change_count > 0 else '📉'}

📈 Средняя сумма:
• Период 1: {p1_avg:,.2f} KZT
• Период 2: {p2_avg:,.2f} KZT
• Изменение: {change_avg:+.1f}% {'📈' if change_avg > 0 else '📉'}
"""
    await update.message.reply_text(comparison)

async def export_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Команда /export - экспорт данных"""
    if df is None:
        await update.message.reply_text("❌ Данные не загружены.")
        return
    
    keyboard = [
        [
            InlineKeyboardButton("📄 CSV", callback_data="export_csv"),
            InlineKeyboardButton("📊 Excel", callback_data="export_excel")
        ],
        [InlineKeyboardButton("🔙 Назад", callback_data="menu_main")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(
        "💾 Выберите формат экспорта:",
        reply_markup=reply_markup
    )

async def history_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Команда /history - история запросов"""
    user_id = update.effective_user.id
    
    if user_id not in user_history or len(user_history[user_id]) == 0:
        await update.message.reply_text("📋 История запросов пуста.\n\nВаши запросы будут сохраняться здесь.")
        return
    
    history_list = user_history[user_id][-10:]  # Последние 10 запросов
    history_text = "📋 Последние 10 запросов:\n\n"
    
    for i, query in enumerate(reversed(history_list), 1):
        timestamp = query.get('timestamp', 'N/A')
        query_text = query.get('query', 'N/A')[:50] + ('...' if len(query.get('query', '')) > 50 else '')
        history_text += f"{i}. {query_text}\n   ⏰ {timestamp}\n\n"
    
    await update.message.reply_text(history_text)

# Callback обработчик для inline кнопок
async def button_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик нажатий на inline кнопки"""
    query = update.callback_query
    await query.answer()
    
    data = query.data
    
    if data == "menu_main":
        # Кнопки как на фото: Дашборд, Быстрые запросы, История, Избранное
        keyboard = [
            [
                InlineKeyboardButton("📊 Дашборд", callback_data="menu_dashboard"),
                InlineKeyboardButton("⚡ Быстрые запросы", callback_data="menu_quick")
            ],
            [
                InlineKeyboardButton("📋 История", callback_data="menu_history"),
                InlineKeyboardButton("⭐ Избранное", callback_data="menu_favorites")
            ],
            [
                InlineKeyboardButton("🤖 Чат с ИИ", callback_data="menu_ai_chat"),
                InlineKeyboardButton("📈 Статистика", callback_data="menu_stats")
            ],
            [
                InlineKeyboardButton("🔄 Сравнить", callback_data="menu_compare"),
                InlineKeyboardButton("💾 Экспорт", callback_data="menu_export")
            ],
            [
                InlineKeyboardButton("🔍 Фильтры", callback_data="menu_filters"),
                InlineKeyboardButton("❓ Помощь", callback_data="menu_help")
            ]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text("🏠 Главное меню:", reply_markup=reply_markup)
    
    elif data == "menu_stats":
        # Отправляем статистику (с кэшированием)
        global stats_cache, cache_timestamp
        if df is None:
            await query.edit_message_text("❌ Данные не загружены.")
            return
        
        try:
            # Проверяем кэш (5 минут)
            now = datetime.now().timestamp()
            if stats_cache and cache_timestamp and (now - cache_timestamp) < CACHE_TTL:
                stats_text = stats_cache
            else:
                total_transactions = len(df)
                total_amount = df['transaction_amount_kzt'].sum()
                avg_amount = df['transaction_amount_kzt'].mean()
                
                category_stats = df.groupby('mcc_category')['transaction_amount_kzt'].sum().sort_values(ascending=False)
                top_categories = category_stats.head(5)
                
                city_stats = df.groupby('merchant_city')['transaction_amount_kzt'].sum().sort_values(ascending=False)
                top_cities = city_stats.head(5)
                
                min_date = df['transaction_timestamp'].min()
                max_date = df['transaction_timestamp'].max()
                
                transaction_types = df['transaction_type'].value_counts()
                
                # Используем список и join для быстрого создания строки
                lines = [
                    "📊 ОБЩАЯ СТАТИСТИКА\n\n",
                    "💰 Финансы:\n",
                    f"• Всего транзакций: {total_transactions:,}\n",
                    f"• Общая сумма: {total_amount:,.2f} KZT\n",
                    f"• Средняя сумма: {avg_amount:,.2f} KZT\n\n",
                    "📅 Период:\n",
                    f"• С {min_date.strftime('%d.%m.%Y') if pd.notna(min_date) else 'N/A'}\n",
                    f"• По {max_date.strftime('%d.%m.%Y') if pd.notna(max_date) else 'N/A'}\n\n",
                    "🏆 ТОП-5 категорий:\n"
                ]
                for category, amount in top_categories.items():
                    lines.append(f"• {category}: {amount:,.2f} KZT\n")
                
                lines.append("\n🌍 ТОП-5 городов:\n")
                for city, amount in top_cities.items():
                    lines.append(f"• {city}: {amount:,.2f} KZT\n")
                
                lines.append("\n💳 Типы транзакций:\n")
                for trans_type, count in transaction_types.items():
                    lines.append(f"• {trans_type}: {count}\n")
                
                stats_text = ''.join(lines)
                
                # Сохраняем в кэш
                stats_cache = stats_text
                cache_timestamp = now
            
            keyboard = [[InlineKeyboardButton("🔙 Назад", callback_data="menu_main")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            await query.edit_message_text(stats_text, reply_markup=reply_markup)
        except Exception as e:
            logger.error(f"Ошибка в stats: {e}")
            await query.edit_message_text(f"❌ Ошибка при формировании статистики: {e}")
    
    elif data == "menu_dashboard":
        keyboard = [
            [
                InlineKeyboardButton("📊 По категориям", callback_data="chart_categories"),
                InlineKeyboardButton("🏙️ По городам", callback_data="chart_cities")
            ],
            [
                InlineKeyboardButton("📈 Временная динамика", callback_data="chart_timeline"),
                InlineKeyboardButton("🥧 Круговая (категории)", callback_data="chart_pie")
            ],
            [InlineKeyboardButton("🔙 Назад", callback_data="menu_main")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text("📊 Выберите тип графика:", reply_markup=reply_markup)
    
    elif data == "menu_compare":
        if df is None:
            await query.edit_message_text("❌ Данные не загружены.")
            return
        
        max_date = df['transaction_timestamp'].max()
        min_date = df['transaction_timestamp'].min()
        mid_date = min_date + (max_date - min_date) / 2
        
        period1 = df[df['transaction_timestamp'] <= mid_date]
        period2 = df[df['transaction_timestamp'] > mid_date]
        
        p1_total = period1['transaction_amount_kzt'].sum()
        p1_count = len(period1)
        p1_avg = period1['transaction_amount_kzt'].mean()
        
        p2_total = period2['transaction_amount_kzt'].sum()
        p2_count = len(period2)
        p2_avg = period2['transaction_amount_kzt'].mean()
        
        change_total = ((p2_total - p1_total) / p1_total * 100) if p1_total > 0 else 0
        change_count = ((p2_count - p1_count) / p1_count * 100) if p1_count > 0 else 0
        change_avg = ((p2_avg - p1_avg) / p1_avg * 100) if p1_avg > 0 else 0
        
        comparison = f"""🔄 СРАВНЕНИЕ ПЕРИОДОВ

📅 Период 1: {min_date.strftime('%d.%m.%Y')} - {mid_date.strftime('%d.%m.%Y')}
📅 Период 2: {mid_date.strftime('%d.%m.%Y')} - {max_date.strftime('%d.%m.%Y')}

💰 Сумма:
• Период 1: {p1_total:,.2f} KZT
• Период 2: {p2_total:,.2f} KZT
• Изменение: {change_total:+.1f}% {'📈' if change_total > 0 else '📉'}

📊 Количество:
• Период 1: {p1_count:,} транзакций
• Период 2: {p2_count:,} транзакций
• Изменение: {change_count:+.1f}% {'📈' if change_count > 0 else '📉'}

📈 Средняя сумма:
• Период 1: {p1_avg:,.2f} KZT
• Период 2: {p2_avg:,.2f} KZT
• Изменение: {change_avg:+.1f}% {'📈' if change_avg > 0 else '📉'}"""
        
        keyboard = [[InlineKeyboardButton("🔙 Назад", callback_data="menu_main")]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text(comparison, reply_markup=reply_markup)
    
    elif data == "menu_export":
        keyboard = [
            [
                InlineKeyboardButton("📄 CSV", callback_data="export_csv"),
                InlineKeyboardButton("📊 Excel", callback_data="export_excel")
            ],
            [InlineKeyboardButton("🔙 Назад", callback_data="menu_main")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text("💾 Выберите формат экспорта:", reply_markup=reply_markup)
    
    elif data == "menu_history":
        user_id = query.from_user.id
        if user_id not in user_history or len(user_history[user_id]) == 0:
            keyboard = [[InlineKeyboardButton("🔙 Назад", callback_data="menu_main")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            await query.edit_message_text("📋 История запросов пуста.\n\nВаши запросы будут сохраняться здесь.", reply_markup=reply_markup)
            return
        
        history_list = user_history[user_id][-10:]
        history_text = "📋 Последние 10 запросов:\n\n"
        for i, query_data in enumerate(reversed(history_list), 1):
            timestamp = query_data.get('timestamp', 'N/A')
            query_text = query_data.get('query', 'N/A')[:50] + ('...' if len(query_data.get('query', '')) > 50 else '')
            history_text += f"{i}. {query_text}\n   ⏰ {timestamp}\n\n"
        
        keyboard = [[InlineKeyboardButton("🔙 Назад", callback_data="menu_main")]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text(history_text, reply_markup=reply_markup)
    
    elif data == "menu_help":
        help_text = """📊 Анализ транзакций Mastercard

Примеры вопросов:
• Общая статистика: "Статистика", "/stats"
• По датам: "Траты за август 2023", "Транзакции в сентябре"
• По категориям: "Категории", "Суммы по категориям"
• По городам: "Траты в Алматы", "Шымкент"
• По типу: "Онлайн покупки", "POS транзакции"
• Топ транзакции: "Самые большие траты", "Топ 10"
• Последние: "Последние 5 транзакций", "Недавние покупки"
• По банку: "Транзакции My Favorite Bank"
• По способу оплаты: "Apple Pay", "QR код"

Команды:
/start - Главное меню
/dashboard - Графики
/compare - Сравнение периодов
/export - Экспорт данных
/history - История запросов"""
        keyboard = [[InlineKeyboardButton("🔙 Назад", callback_data="menu_main")]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text(help_text, reply_markup=reply_markup)
    
    elif data.startswith("chart_"):
        chart_type = data.replace("chart_", "")
        await send_chart(query, chart_type)
    
    elif data.startswith("export_"):
        export_type = data.replace("export_", "")
        await export_data(query, export_type)
    
    elif data == "menu_quick":
        # Быстрые запросы
        keyboard = [
            [
                InlineKeyboardButton("📋 Последние 5", callback_data="quick_last_5"),
                InlineKeyboardButton("📋 Последние 10", callback_data="quick_last_10")
            ],
            [
                InlineKeyboardButton("🏆 ТОП 5", callback_data="quick_top_5"),
                InlineKeyboardButton("🏆 ТОП 10", callback_data="quick_top_10")
            ],
            [
                InlineKeyboardButton("📊 По категориям", callback_data="quick_categories"),
                InlineKeyboardButton("🌍 По городам", callback_data="quick_cities")
            ],
            [
                InlineKeyboardButton("📈 График категорий", callback_data="chart_categories"),
                InlineKeyboardButton("📈 График городов", callback_data="chart_cities")
            ],
            [InlineKeyboardButton("🔙 Назад", callback_data="menu_main")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text("⚡ Быстрые запросы - выберите действие:", reply_markup=reply_markup)
    
    elif data == "menu_filters":
        # Меню фильтров
        if df is None:
            await query.edit_message_text("❌ Данные не загружены.")
            return
        
        # Получаем уникальные значения для фильтров
        cities = df['merchant_city'].dropna().unique()[:5]
        categories = df['mcc_category'].dropna().unique()[:5]
        
        keyboard = [
            [InlineKeyboardButton("🏙️ По городам", callback_data="filter_city_menu")],
            [InlineKeyboardButton("🏷️ По категориям", callback_data="filter_category_menu")],
            [InlineKeyboardButton("💳 По типу транзакций", callback_data="filter_type_menu")],
            [InlineKeyboardButton("📱 По способу оплаты", callback_data="filter_wallet_menu")],
            [InlineKeyboardButton("🔙 Назад", callback_data="menu_main")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text("🔍 Фильтры - выберите параметр:", reply_markup=reply_markup)
    
    elif data.startswith("quick_"):
        await handle_quick_query(query, data)
    
    elif data.startswith("filter_"):
        await handle_filter_menu(query, data)
    
    elif data == "menu_ai_chat":
        # Включение/выключение режима чата с ИИ
        user_id = query.from_user.id
        ai_chat_mode[user_id] = not ai_chat_mode.get(user_id, False)
        
        if ai_chat_mode[user_id]:
            status_text = "✅ Режим чата с ИИ включен!\n\nТеперь все ваши сообщения будут анализироваться через ИИ."
            keyboard = [
                [InlineKeyboardButton("❌ Выключить", callback_data="menu_ai_chat")],
                [InlineKeyboardButton("🔙 Назад", callback_data="menu_main")]
            ]
        else:
            status_text = "❌ Режим чата с ИИ выключен.\n\nОбычный режим работы."
            keyboard = [
                [InlineKeyboardButton("✅ Включить", callback_data="menu_ai_chat")],
                [InlineKeyboardButton("🔙 Назад", callback_data="menu_main")]
            ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text(status_text, reply_markup=reply_markup)
    
    elif data == "menu_favorites":
        # Показываем избранное
        user_id = query.from_user.id
        if user_id not in user_favorites or len(user_favorites[user_id]) == 0:
            keyboard = [[InlineKeyboardButton("🔙 Назад", callback_data="menu_main")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            await query.edit_message_text("⭐ Избранное пусто.\n\nИспользуйте кнопку ⭐ под любым результатом, чтобы добавить в избранное.", reply_markup=reply_markup)
            return
        
        favorites_list = user_favorites[user_id][-10:]
        favorites_text = "⭐ Избранное:\n\n"
        for i, fav in enumerate(reversed(favorites_list), 1):
            title = fav.get('title', 'Без названия')[:50]
            timestamp = fav.get('timestamp', 'N/A')
            favorites_text += f"{i}. {title}\n   ⏰ {timestamp}\n\n"
        
        keyboard = [
            [InlineKeyboardButton("🗑️ Очистить", callback_data="favorites_clear")],
            [InlineKeyboardButton("🔙 Назад", callback_data="menu_main")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text(favorites_text, reply_markup=reply_markup)
    
    elif data == "favorites_clear":
        user_id = query.from_user.id
        user_favorites[user_id] = []
        keyboard = [[InlineKeyboardButton("🔙 Назад", callback_data="menu_main")]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text("✅ Избранное очищено!", reply_markup=reply_markup)
    
    elif data == "favorite_add":
        # Добавление в избранное
        user_id = query.from_user.id
        if user_id not in user_favorites:
            user_favorites[user_id] = []
        # Сохраняем последний запрос пользователя
        if user_id in user_history and len(user_history[user_id]) > 0:
            last_query = user_history[user_id][-1]
            user_favorites[user_id].append({
                'title': last_query.get('query', 'Запрос')[:100],
                'timestamp': datetime.now().strftime('%d.%m.%Y %H:%M'),
                'query': last_query.get('query', '')
            })
            await query.answer("✅ Добавлено в избранное!")
        else:
            await query.answer("❌ Нечего добавить")

async def send_chart(query, chart_type):
    """Отправка графика"""
    try:
        if chart_type == "categories":
            buf = create_category_chart()
            caption = "📊 ТОП-10 категорий по сумме транзакций"
        elif chart_type == "cities":
            buf = create_city_chart()
            caption = "🏙️ Сумма транзакций по городам"
        elif chart_type == "timeline":
            buf = create_timeline_chart()
            caption = "📈 Динамика транзакций по дням"
        elif chart_type == "pie":
            buf = create_pie_chart_categories()
            caption = "🥧 Распределение транзакций по категориям"
        else:
            await query.edit_message_text("❌ Неизвестный тип графика")
            return
        
        keyboard = [
            [
                InlineKeyboardButton("📊 Другой график", callback_data="menu_dashboard"),
                InlineKeyboardButton("💾 Экспорт", callback_data="menu_export")
            ],
            [InlineKeyboardButton("🏠 Меню", callback_data="menu_main")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.message.reply_photo(photo=InputFile(buf, filename="chart.png"), caption=caption, reply_markup=reply_markup)
        await query.edit_message_text("✅ График готов!")
        buf.close()
    except Exception as e:
        logger.error(f"Ошибка при создании графика: {e}")
        await query.edit_message_text(f"❌ Ошибка при создании графика: {e}")

async def handle_quick_query(query, data):
    """Обработка быстрых запросов"""
    if df is None:
        await query.edit_message_text("❌ Данные не загружены.")
        return
    
    try:
        quick_type = data.replace("quick_", "")
        response = ""
        
        if quick_type == "last_5":
            # Уже отсортировано при загрузке
            last_transactions = df.head(5)
            lines = ["📋 Последние 5 транзакций:\n\n"]
            for row in last_transactions.itertuples(index=False):
                date = row.transaction_timestamp.strftime('%d.%m.%Y %H:%M') if pd.notna(row.transaction_timestamp) else 'N/A'
                amount = row.transaction_amount_kzt
                category = row.mcc_category if pd.notna(row.mcc_category) else 'N/A'
                city = row.merchant_city if pd.notna(row.merchant_city) else 'N/A'
                lines.append(f"💰 {amount:,.2f} KZT\n📅 {date} | 📍 {city}\n🏷️ {category}\n\n")
            response = ''.join(lines)
        
        elif quick_type == "last_10":
            last_transactions = df.head(10)
            lines = ["📋 Последние 10 транзакций:\n\n"]
            for row in last_transactions.itertuples(index=False):
                date = row.transaction_timestamp.strftime('%d.%m.%Y %H:%M') if pd.notna(row.transaction_timestamp) else 'N/A'
                amount = row.transaction_amount_kzt
                category = row.mcc_category if pd.notna(row.mcc_category) else 'N/A'
                city = row.merchant_city if pd.notna(row.merchant_city) else 'N/A'
                lines.append(f"💰 {amount:,.2f} KZT | {date} | {city}\n🏷️ {category}\n\n")
            response = ''.join(lines)
        
        elif quick_type == "top_5":
            top_transactions = df.nlargest(5, 'transaction_amount_kzt')
            lines = ["🏆 ТОП-5 самых больших транзакций:\n\n"]
            for row in top_transactions.itertuples(index=False):
                date = row.transaction_timestamp.strftime('%d.%m.%Y %H:%M') if pd.notna(row.transaction_timestamp) else 'N/A'
                amount = row.transaction_amount_kzt
                category = row.mcc_category if pd.notna(row.mcc_category) else 'N/A'
                city = row.merchant_city if pd.notna(row.merchant_city) else 'N/A'
                lines.append(f"💰 {amount:,.2f} KZT\n📅 {date} | 📍 {city}\n🏷️ {category}\n\n")
            response = ''.join(lines)
        
        elif quick_type == "top_10":
            top_transactions = df.nlargest(10, 'transaction_amount_kzt')
            lines = ["🏆 ТОП-10 самых больших транзакций:\n\n"]
            for row in top_transactions.itertuples(index=False):
                date = row.transaction_timestamp.strftime('%d.%m.%Y %H:%M') if pd.notna(row.transaction_timestamp) else 'N/A'
                amount = row.transaction_amount_kzt
                category = row.mcc_category if pd.notna(row.mcc_category) else 'N/A'
                city = row.merchant_city if pd.notna(row.merchant_city) else 'N/A'
                lines.append(f"💰 {amount:,.2f} KZT | {date} | {city}\n🏷️ {category}\n\n")
            response = ''.join(lines)
        
        elif quick_type == "categories":
            category_stats = df.groupby('mcc_category')['transaction_amount_kzt'].agg(['sum', 'count']).sort_values('sum', ascending=False).head(10)
            lines = ["📊 ТОП-10 категорий:\n\n"]
            for category, row in category_stats.items():
                lines.append(f"🏷️ {category}\n💰 {row['sum']:,.2f} KZT ({row['count']} транзакций)\n\n")
            response = ''.join(lines)
        
        elif quick_type == "cities":
            city_stats = df.groupby('merchant_city')['transaction_amount_kzt'].agg(['sum', 'count']).sort_values('sum', ascending=False)
            lines = ["🌍 Статистика по городам:\n\n"]
            for city, row in city_stats.items():
                lines.append(f"🏙️ {city}\n💰 {row['sum']:,.2f} KZT ({row['count']} транзакций)\n\n")
            response = ''.join(lines)
        
        if response:
            keyboard = [
                [
                    InlineKeyboardButton("📈 График", callback_data="chart_categories" if quick_type == "categories" else "chart_cities" if quick_type == "cities" else "menu_dashboard"),
                    InlineKeyboardButton("💾 Экспорт", callback_data="menu_export")
                ],
                [InlineKeyboardButton("🔙 Назад", callback_data="menu_quick")]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            if len(response) > 4096:
                # Разбиваем на части
                parts = [response[i:i+4000] for i in range(0, len(response), 4000)]
                for i, part in enumerate(parts):
                    if i == len(parts) - 1:
                        await query.message.reply_text(part, reply_markup=reply_markup)
                    else:
                        await query.message.reply_text(part)
                await query.edit_message_text("✅ Результаты готовы!")
            else:
                await query.edit_message_text(response, reply_markup=reply_markup)
        else:
            await query.edit_message_text("❌ Неизвестный быстрый запрос")
            
    except Exception as e:
        logger.error(f"Ошибка в быстром запросе: {e}")
        await query.edit_message_text(f"❌ Ошибка: {e}")

async def handle_filter_menu(query, data):
    """Обработка меню фильтров"""
    if df is None:
        await query.edit_message_text("❌ Данные не загружены.")
        return
    
    try:
        # Сначала проверяем, применяется ли фильтр (не меню)
        if data.startswith("filter_city_") and not data.endswith("_menu"):
            city = data.replace("filter_city_", "")
            filtered = df[df['merchant_city'] == city]
            total = filtered['transaction_amount_kzt'].sum()
            count = len(filtered)
            avg = filtered['transaction_amount_kzt'].mean()
            
            response = f"🌍 Фильтр: {city}\n\n"
            response += f"• Транзакций: {count:,}\n"
            response += f"• Общая сумма: {total:,.2f} KZT\n"
            response += f"• Средняя сумма: {avg:,.2f} KZT\n"
            
            keyboard = [
                [
                    InlineKeyboardButton("📈 График", callback_data="chart_cities"),
                    InlineKeyboardButton("💾 Экспорт", callback_data="menu_export")
                ],
                [InlineKeyboardButton("🔙 Назад", callback_data="menu_filters")]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            await query.edit_message_text(response, reply_markup=reply_markup)
            return
            
        elif data.startswith("filter_category_") and not data.endswith("_menu"):
            category = data.replace("filter_category_", "")
            filtered = df[df['mcc_category'] == category]
            total = filtered['transaction_amount_kzt'].sum()
            count = len(filtered)
            avg = filtered['transaction_amount_kzt'].mean()
            
            response = f"🏷️ Фильтр: {category}\n\n"
            response += f"• Транзакций: {count:,}\n"
            response += f"• Общая сумма: {total:,.2f} KZT\n"
            response += f"• Средняя сумма: {avg:,.2f} KZT\n"
            
            keyboard = [
                [
                    InlineKeyboardButton("📈 График", callback_data="chart_categories"),
                    InlineKeyboardButton("💾 Экспорт", callback_data="menu_export")
                ],
                [InlineKeyboardButton("🔙 Назад", callback_data="menu_filters")]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            await query.edit_message_text(response, reply_markup=reply_markup)
            return
            
        elif data.startswith("filter_type_") and not data.endswith("_menu"):
            trans_type = data.replace("filter_type_", "")
            filtered = df[df['transaction_type'] == trans_type]
            total = filtered['transaction_amount_kzt'].sum()
            count = len(filtered)
            avg = filtered['transaction_amount_kzt'].mean()
            
            response = f"💳 Фильтр: {trans_type}\n\n"
            response += f"• Транзакций: {count:,}\n"
            response += f"• Общая сумма: {total:,.2f} KZT\n"
            response += f"• Средняя сумма: {avg:,.2f} KZT\n"
            
            keyboard = [
                [InlineKeyboardButton("💾 Экспорт", callback_data="menu_export")],
                [InlineKeyboardButton("🔙 Назад", callback_data="menu_filters")]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            await query.edit_message_text(response, reply_markup=reply_markup)
            return
            
        elif data.startswith("filter_wallet_") and not data.endswith("_menu"):
            wallet = data.replace("filter_wallet_", "")
            filtered = df[df['wallet_type'] == wallet]
            total = filtered['transaction_amount_kzt'].sum()
            count = len(filtered)
            avg = filtered['transaction_amount_kzt'].mean()
            
            response = f"📱 Фильтр: {wallet}\n\n"
            response += f"• Транзакций: {count:,}\n"
            response += f"• Общая сумма: {total:,.2f} KZT\n"
            response += f"• Средняя сумма: {avg:,.2f} KZT\n"
            
            keyboard = [
                [InlineKeyboardButton("💾 Экспорт", callback_data="menu_export")],
                [InlineKeyboardButton("🔙 Назад", callback_data="menu_filters")]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            await query.edit_message_text(response, reply_markup=reply_markup)
            return
        
        # Показываем меню выбора
        filter_type = data.replace("filter_", "").replace("_menu", "")
        
        if filter_type == "city":
            cities = df['merchant_city'].dropna().unique()[:6]
            keyboard = []
            for i in range(0, len(cities), 2):
                row = []
                row.append(InlineKeyboardButton(f"🏙️ {cities[i]}", callback_data=f"filter_city_{cities[i]}"))
                if i + 1 < len(cities):
                    row.append(InlineKeyboardButton(f"🏙️ {cities[i+1]}", callback_data=f"filter_city_{cities[i+1]}"))
                keyboard.append(row)
            keyboard.append([InlineKeyboardButton("🔙 Назад", callback_data="menu_filters")])
            reply_markup = InlineKeyboardMarkup(keyboard)
            await query.edit_message_text("🏙️ Выберите город:", reply_markup=reply_markup)
        
        elif filter_type == "category":
            categories = df['mcc_category'].dropna().unique()[:6]
            keyboard = []
            for i in range(0, len(categories), 2):
                row = []
                cat_short = categories[i][:20] + "..." if len(categories[i]) > 20 else categories[i]
                row.append(InlineKeyboardButton(f"🏷️ {cat_short}", callback_data=f"filter_category_{categories[i]}"))
                if i + 1 < len(categories):
                    cat_short2 = categories[i+1][:20] + "..." if len(categories[i+1]) > 20 else categories[i+1]
                    row.append(InlineKeyboardButton(f"🏷️ {cat_short2}", callback_data=f"filter_category_{categories[i+1]}"))
                keyboard.append(row)
            keyboard.append([InlineKeyboardButton("🔙 Назад", callback_data="menu_filters")])
            reply_markup = InlineKeyboardMarkup(keyboard)
            await query.edit_message_text("🏷️ Выберите категорию:", reply_markup=reply_markup)
        
        elif filter_type == "type":
            keyboard = [
                [InlineKeyboardButton("💳 POS (Офлайн)", callback_data="filter_type_POS")],
                [InlineKeyboardButton("💻 ECOM (Онлайн)", callback_data="filter_type_ECOM")],
                [InlineKeyboardButton("📄 BILL_PAYMENT (Счета)", callback_data="filter_type_BILL_PAYMENT")],
                [InlineKeyboardButton("🔙 Назад", callback_data="menu_filters")]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            await query.edit_message_text("💳 Выберите тип транзакции:", reply_markup=reply_markup)
        
        elif filter_type == "wallet":
            wallets = df['wallet_type'].dropna().unique()[:6]
            keyboard = []
            for wallet in wallets:
                if wallet and wallet != '\\N' and pd.notna(wallet):
                    keyboard.append([InlineKeyboardButton(f"📱 {wallet}", callback_data=f"filter_wallet_{wallet}")])
            keyboard.append([InlineKeyboardButton("🔙 Назад", callback_data="menu_filters")])
            reply_markup = InlineKeyboardMarkup(keyboard)
            await query.edit_message_text("📱 Выберите способ оплаты:", reply_markup=reply_markup)
        
    except Exception as e:
        logger.error(f"Ошибка в фильтрах: {e}")
        await query.edit_message_text(f"❌ Ошибка: {e}")

async def export_data(query, export_type):
    """Экспорт данных"""
    try:
        if export_type == "csv":
            buf = io.BytesIO()
            df.to_csv(buf, index=False, encoding='utf-8-sig')
            buf.seek(0)
            filename = f"transactions_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
            await query.message.reply_document(
                document=InputFile(buf, filename=filename),
                caption="📄 Экспорт данных в CSV"
            )
            buf.close()
        
        elif export_type == "excel":
            buf = io.BytesIO()
            # Создаем Excel файл с правильной структурой
            from openpyxl import Workbook
            from openpyxl.utils.dataframe import dataframe_to_rows
            
            wb = Workbook()
            ws = wb.active
            ws.title = "Transactions"
            
            # Добавляем данные из DataFrame
            for r in dataframe_to_rows(df, index=False, header=True):
                ws.append(r)
            
            # Сохраняем в буфер
            wb.save(buf)
            buf.seek(0)
            
            filename = f"transactions_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
            await query.message.reply_document(
                document=InputFile(buf, filename=filename),
                caption="📊 Экспорт данных в Excel"
            )
            buf.close()
        
        keyboard = [
            [InlineKeyboardButton("📊 Графики", callback_data="menu_dashboard")],
            [InlineKeyboardButton("🏠 Меню", callback_data="menu_main")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text("✅ Данные успешно экспортированы!", reply_markup=reply_markup)
    except Exception as e:
        logger.error(f"Ошибка при экспорте: {e}")
        await query.edit_message_text(f"❌ Ошибка при экспорте: {e}")

async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Обработчик ошибок"""
    logger.error(f"Ошибка при обработке обновления: {context.error}", exc_info=context.error)
    
    # Обработка конфликта (409) - несколько экземпляров бота
    if isinstance(context.error, Conflict):
        logger.warning("Обнаружен конфликт - возможно запущено несколько экземпляров бота")
        try:
            # Пытаемся удалить webhook, если есть
            await context.bot.delete_webhook(drop_pending_updates=True)
            logger.info("Webhook удален, попробуйте перезапустить бота")
        except Exception as e:
            logger.error(f"Ошибка при удалении webhook: {e}")
    
    # Обработка сетевых ошибок
    elif isinstance(context.error, NetworkError):
        logger.warning("Сетевая ошибка, повторная попытка...")

def main():
    """Основная функция запуска бота"""
    # Загрузка токена из переменной окружения
    token = os.getenv('TELEGRAM_BOT_TOKEN')
    
    if not token:
        logger.error("TELEGRAM_BOT_TOKEN не установлен!")
        print("⚠️  ВНИМАНИЕ: Установите переменную окружения TELEGRAM_BOT_TOKEN")
        print("   Например: export TELEGRAM_BOT_TOKEN='ваш_токен'")
        print("   Или создайте файл .env с: TELEGRAM_BOT_TOKEN=ваш_токен")
        return
    
    # Загрузка данных
    if not load_transactions():
        logger.error("Не удалось загрузить данные транзакций!")
        return
    
    # Создание приложения
    application = Application.builder().token(token).build()
    
    # Регистрация обработчиков
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("stats", stats_command))
    application.add_handler(CommandHandler("dashboard", dashboard_command))
    application.add_handler(CommandHandler("compare", compare_periods_command))
    application.add_handler(CommandHandler("export", export_command))
    application.add_handler(CommandHandler("history", history_command))
    application.add_handler(CallbackQueryHandler(button_callback))
    # Обработчик файлов должен быть ДО обработчика текстовых сообщений
    application.add_handler(MessageHandler(filters.Document.ALL, handle_file))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, analyze_message))
    
    # Регистрация обработчика ошибок
    application.add_error_handler(error_handler)
    
    # Запуск бота
    logger.info("Бот запущен...")
    if OPENROUTER_API_KEY:
        logger.info("ИИ режим включен (OpenRouter API)")
    else:
        logger.warning("ИИ режим отключен (не установлен OPENROUTER_API_KEY)")
    
    # Запуск polling (drop_pending_updates автоматически удаляет webhook)
    application.run_polling(
        allowed_updates=Update.ALL_TYPES,
        drop_pending_updates=True  # Это автоматически удалит webhook перед запуском
    )

if __name__ == '__main__':
    main()

